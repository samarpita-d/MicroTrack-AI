
import React, { useState, useRef } from 'react';
import { Camera, Upload, ShieldAlert, Thermometer, CheckCircle, RefreshCw, Loader2 } from 'lucide-react';
import { analyzePackaging } from '../services/geminiService';
import { ScanResult } from '../types';

const Scanner: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        setImage(reader.result as string);
        processImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = async (base64: string) => {
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      const analysis = await analyzePackaging(base64);
      setResult({
        ...analysis,
        timestamp: new Date().toLocaleTimeString()
      });
    } catch (err) {
      setError("Failed to analyze image. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto space-y-8 animate-fadeIn">
      <header className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">AI Packaging Scanner</h1>
        <p className="text-slate-500">Scan food containers or labels to analyze microplastic risk.</p>
      </header>

      {!image ? (
        <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center space-y-6">
          <div className="w-20 h-20 bg-teal-50 rounded-full flex items-center justify-center mx-auto text-teal-600">
            <Camera className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-bold">Ready to analyze</h3>
            <p className="text-slate-500 text-sm max-w-xs mx-auto">
              Upload a clear photo of the product packaging or material label.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-4 px-10 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <Upload className="w-5 h-5" />
              Upload Image
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileUpload} 
              className="hidden" 
              accept="image/*" 
            />
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="aspect-square bg-slate-100 rounded-3xl overflow-hidden relative shadow-inner">
              <img src={image} alt="Preview" className="w-full h-full object-cover" />
              {loading && (
                <div className="absolute inset-0 bg-white/60 backdrop-blur-sm flex flex-col items-center justify-center text-teal-600 animate-pulse">
                  <Loader2 className="w-12 h-12 animate-spin mb-4" />
                  <p className="font-bold">AI Analyzing...</p>
                </div>
              )}
            </div>
            <button 
              onClick={reset}
              className="w-full py-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-600 flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" /> New Scan
            </button>
          </div>

          <div className="space-y-6">
            {result ? (
              <div className="bg-white border border-slate-100 p-8 rounded-3xl shadow-sm space-y-6 animate-slideUp">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">{result.productName}</h2>
                    <p className="text-slate-500 text-sm">{result.materialType}</p>
                  </div>
                  <div className={`px-4 py-1.5 rounded-full font-black text-sm uppercase tracking-wider ${
                    result.riskLevel === 'High' ? 'bg-rose-100 text-rose-700' :
                    result.riskLevel === 'Medium' ? 'bg-amber-100 text-amber-700' :
                    'bg-emerald-100 text-emerald-700'
                  }`}>
                    {result.riskLevel} Risk
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <Thermometer className="w-5 h-5 text-amber-500 shrink-0 mt-1" />
                    <div>
                      <p className="font-bold text-sm">Heat Safety</p>
                      <p className="text-slate-600 text-sm">{result.heatRisk}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <p className="font-bold text-sm flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-teal-600" />
                      Safety Recommendations
                    </p>
                    <ul className="space-y-2">
                      {result.recommendations.map((rec, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
                          <CheckCircle className="w-4 h-4 text-teal-500 mt-0.5 shrink-0" />
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <button className="w-full bg-teal-600 text-white font-bold py-4 rounded-2xl shadow-lg hover:bg-teal-700 transition-all">
                  Log This Exposure
                </button>
              </div>
            ) : error ? (
              <div className="bg-rose-50 border border-rose-100 p-8 rounded-3xl text-center space-y-4">
                <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto" />
                <h3 className="font-bold text-rose-900">Analysis Failed</h3>
                <p className="text-rose-700 text-sm">{error}</p>
              </div>
            ) : (
              <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100 flex flex-col items-center justify-center text-center space-y-4 h-full">
                <p className="text-slate-400 font-medium">Results will appear here...</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Scanner;
