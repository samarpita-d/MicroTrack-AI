
import React from 'react';

interface LogoProps {
  className?: string;
  animate?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = "w-16 h-16", animate = true }) => {
  return (
    <div className={`relative ${className} ${animate ? 'animate-logo-float' : ''}`}>
      <svg 
        viewBox="0 0 100 100" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-2xl"
      >
        {/* Main Hexagonal Molecule Base */}
        <path 
          d="M50 5L89.5 27.5V72.5L50 95L10.5 72.5V27.5L50 5Z" 
          stroke="url(#logo-grad)" 
          strokeWidth="3.5" 
          strokeLinejoin="round" 
          className="opacity-90"
        />
        
        {/* Subtle Background Glow for Text */}
        <circle cx="50" cy="50" r="30" fill="url(#logo-inner-glow)" opacity="0.15" />

        {/* Brand Text Inside Hexagon */}
        <text 
          x="50" 
          y="48" 
          textAnchor="middle" 
          fill="url(#logo-grad)" 
          fontSize="8.5" 
          fontWeight="900" 
          fontFamily="Inter, sans-serif"
          letterSpacing="0.05em"
          className="uppercase"
        >
          MicroTrack
        </text>
        <text 
          x="50" 
          y="65" 
          textAnchor="middle" 
          fill="url(#logo-grad-alt)" 
          fontSize="14" 
          fontWeight="900" 
          fontFamily="Inter, sans-serif"
          className="uppercase"
        >
          AI
        </text>
        
        {/* Digital Tracking Accents at Corners */}
        <path d="M25 25L32 32M75 25L68 32M25 75L32 68M75 75L68 68" stroke="url(#logo-grad)" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />

        {/* Dynamic Scanning Line */}
        {animate && (
          <g className="animate-scan-group">
            <line 
              x1="15" y1="0" x2="85" y2="0" 
              stroke="#2dd4bf" 
              strokeWidth="2" 
              strokeLinecap="round"
              className="animate-scan-line-v2"
              filter="url(#glow)"
            />
            {/* Trailing scan gradient */}
            <rect x="15" y="-10" width="70" height="10" fill="url(#scan-trail)" className="animate-scan-line-v2" />
          </g>
        )}

        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          <linearGradient id="logo-grad" x1="0" y1="0" x2="100" y2="100">
            <stop stopColor="#2dd4bf" />
            <stop offset="1" stopColor="#3b82f6" />
          </linearGradient>
          <linearGradient id="logo-grad-alt" x1="0" y1="0" x2="100" y2="100">
            <stop stopColor="#10b981" />
            <stop offset="1" stopColor="#06b6d4" />
          </linearGradient>
          <radialGradient id="logo-inner-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#2dd4bf" />
            <stop offset="100%" stopColor="transparent" />
          </radialGradient>
          <linearGradient id="scan-trail" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="transparent" />
            <stop offset="100%" stopColor="#2dd4bf" stopOpacity="0.3" />
          </linearGradient>
        </defs>
      </svg>
      
      <style>{`
        @keyframes logo-float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        .animate-logo-float {
          animation: logo-float 5s infinite ease-in-out;
        }
        @keyframes scan-v2 {
          0% { transform: translateY(15px); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(85px); opacity: 0; }
        }
        .animate-scan-line-v2 {
          animation: scan-v2 4s infinite cubic-bezier(0.4, 0, 0.2, 1);
        }
      `}</style>
    </div>
  );
};

export default Logo;
