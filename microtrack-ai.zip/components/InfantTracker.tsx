
import React from 'react';
import { Baby, Heart, ShieldPlus, Sparkles, Thermometer, Brain } from 'lucide-react';

const InfantTracker: React.FC = () => {
  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-8 animate-fadeIn">
      <header className="bg-rose-500 rounded-[2.5rem] p-10 text-white relative overflow-hidden">
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-white/10 rounded-full -mb-32 -mr-32 blur-3xl" />
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="w-24 h-24 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30">
            <Baby className="w-12 h-12" />
          </div>
          <div className="space-y-2 text-center md:text-left">
            <h1 className="text-4xl font-black">Infant & Pregnancy Tracker</h1>
            <p className="text-rose-100 text-lg max-w-xl">
              Specialized monitoring to protect the most vulnerable from microplastic exposure.
            </p>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
              <ShieldPlus className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold">Prenatal Exposure Monitoring</h3>
          </div>
          <p className="text-slate-600">
            Microplastics can pass through the placental barrier. Use this tracker to log maternal exposure and receive risk-mitigation alerts for your baby.
          </p>
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase text-slate-400 tracking-wider">Today's Risk Check</h4>
            <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center justify-between">
              <span className="font-medium text-emerald-800">Current Intake: Within Safe Range</span>
              <Sparkles className="w-5 h-5 text-emerald-500" />
            </div>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
              <Thermometer className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold">Safe Feeding Checklist</h3>
          </div>
          <div className="grid grid-cols-1 gap-3">
            <CheckItem text="Use glass or PPSU bottles for milk" />
            <CheckItem text="Avoid shaking plastic bottles when hot" />
            <CheckItem text="Use stainless steel weaning spoons" />
            <CheckItem text="Hand-wash bottles (avoid dishwasher heat)" />
          </div>
        </div>
      </div>

      <section className="bg-slate-900 rounded-[2.5rem] p-10 text-white space-y-8">
        <div className="flex items-center gap-4">
          <Brain className="w-8 h-8 text-teal-400" />
          <h3 className="text-2xl font-bold">Research-Backed Insights</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <InsightCard 
            title="Heat & Particles"
            content="Polypropylene bottles can release millions of microplastics per liter when exposed to 95°C water."
          />
          <InsightCard 
            title="Nipple Safety"
            content="Medical-grade silicone nipples release significantly fewer particles than latex alternatives."
          />
          <InsightCard 
            title="Maternal Transfer"
            content="Studies show microplastics in human placentas, emphasizing the need for filtered hydration during pregnancy."
          />
        </div>
      </section>

      <div className="bg-rose-50 border border-rose-100 p-8 rounded-3xl text-center space-y-4">
        <Heart className="w-10 h-10 text-rose-500 mx-auto" />
        <h3 className="text-xl font-bold text-rose-900">Your Data is Secure</h3>
        <p className="text-rose-700 max-w-lg mx-auto text-sm">
          Pregnancy and infant data is encrypted end-to-end. We do not sell or share any information related to your family's health.
        </p>
      </div>
    </div>
  );
};

const CheckItem = ({ text }: { text: string }) => (
  <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl">
    <div className="w-5 h-5 rounded-full border-2 border-teal-500 flex items-center justify-center">
      <div className="w-2 h-2 rounded-full bg-teal-500" />
    </div>
    <span className="text-sm font-medium text-slate-700">{text}</span>
  </div>
);

const InsightCard = ({ title, content }: { title: string, content: string }) => (
  <div className="space-y-4 border-l-2 border-teal-500/30 pl-6">
    <h4 className="font-bold text-teal-400 uppercase text-xs tracking-widest">{title}</h4>
    <p className="text-slate-400 text-sm leading-relaxed">{content}</p>
  </div>
);

export default InfantTracker;
