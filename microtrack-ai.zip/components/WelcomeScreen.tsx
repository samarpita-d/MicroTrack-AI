
import React from 'react';
import Logo from './Logo';

interface WelcomeScreenProps {
  onContinue: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onContinue }) => {
  return (
    <div className="relative h-screen w-full flex flex-col items-center justify-center overflow-hidden bg-slate-900 font-sans">
      {/* Dynamic Background Layer: Microplastics Investigation Image */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat transition-transform duration-[20s] ease-in-out scale-110 animate-zoom-slow"
        style={{
          backgroundImage: `url('https://replicate.delivery/pbxt/JRv9h3ySreB0E635O7R0R0Yv4kS9Yn3E/Microplastics_Investigation.jpg')`,
        }}
      />
      
      {/* High-Contrast Gradient Overlay */}
      <div className="absolute inset-0 z-10 bg-gradient-to-t from-slate-950 via-slate-900/60 to-slate-950/90 backdrop-blur-[2px]" />

      {/* Main Content Container */}
      <div className="relative z-20 flex flex-col items-center text-center px-6 max-w-5xl animate-content-in">
        
        {/* NEW CUSTOM LOGO - Positioned above the heading */}
        <div className="mb-12">
          <Logo className="w-48 h-48 md:w-64 md:h-64" />
        </div>

        {/* Main Brand Heading */}
        <div className="space-y-4">
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black text-white tracking-tighter drop-shadow-[0_20px_40px_rgba(0,0,0,1)] leading-none select-none">
            MicroTrack <span className="bg-gradient-to-r from-teal-300 to-cyan-300 bg-clip-text text-transparent">AI</span>
          </h1>
          
          {/* Tagline */}
          <p className="text-xl md:text-2xl lg:text-3xl text-emerald-300 font-bold uppercase tracking-[0.45em] drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)] max-w-4xl leading-snug mx-auto">
            Making invisible plastic visible
          </p>
        </div>

        {/* Action Section */}
        <div className="mt-20">
          <button
            onClick={onContinue}
            className="group relative px-28 py-8 bg-emerald-500 hover:bg-emerald-400 text-white text-2xl font-black rounded-full transition-all duration-500 transform hover:scale-110 active:scale-95 shadow-[0_25px_100px_rgba(16,185,129,0.7)] overflow-hidden"
          >
            <span className="relative z-10 uppercase tracking-[0.25em] flex items-center gap-4">
              Continue
              <svg className="w-8 h-8 transform transition-transform duration-500 group-hover:translate-x-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-teal-400 via-emerald-400 to-teal-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-gradient-x" />
          </button>
        </div>
      </div>

      {/* Ambient Data Labels */}
      <div className="absolute bottom-10 left-10 z-20 flex flex-col gap-2">
        <div className="flex items-center gap-3 text-white/50 text-[10px] font-mono tracking-widest uppercase">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          Scanner: MT_SCAN_PRO_4.0
        </div>
        <div className="text-white/30 text-[10px] font-mono tracking-widest uppercase pl-5">
          Detection: Microplastic_Analysis_Active
        </div>
      </div>

      <style>{`
        @keyframes content-in {
          from { opacity: 0; transform: translateY(60px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-content-in {
          animation: content-in 2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes zoom-slow {
          0% { transform: scale(1.1); }
          50% { transform: scale(1.2); }
          100% { transform: scale(1.1); }
        }
        .animate-zoom-slow {
          animation: zoom-slow 40s infinite ease-in-out;
        }
        @keyframes gradient-x {
          0% { background-position: 0% 50%; }
          100% { background-position: 100% 50%; }
        }
        .animate-gradient-x {
          background-size: 200% 200%;
          animation: gradient-x 3s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default WelcomeScreen;
