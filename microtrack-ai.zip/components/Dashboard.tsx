
import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { AlertTriangle, TrendingDown, Flame, CheckCircle2, ChevronRight, ShieldAlert, Sparkles, Baby } from 'lucide-react';

const COLORS = ['#0d9488', '#0ea5e9', '#6366f1', '#f43f5e'];

const Dashboard: React.FC = () => {
  // Simulating a dynamic score for demonstration - in a real app this would come from a global state or API
  const [score] = useState(68); 

  const getStatusInfo = (val: number) => {
    if (val <= 30) {
      return {
        label: "Low Risk",
        message: "Fine great low intake today",
        color: "text-emerald-600",
        bg: "bg-emerald-50",
        border: "border-emerald-100",
        pieColor: "#10b981",
        icon: <CheckCircle2 className="w-6 h-6 text-emerald-500" />
      };
    } else if (val > 30 && val <= 70) {
      return {
        label: "Medium Risk",
        message: "Medium we can do better",
        color: "text-amber-600",
        bg: "bg-amber-50",
        border: "border-amber-100",
        pieColor: "#f59e0b",
        icon: <TrendingDown className="w-6 h-6 text-amber-500" />
      };
    } else {
      return {
        label: "High Alert",
        message: "HIGH ALERT: Dangerous exposure detected!",
        color: "text-rose-600",
        bg: "bg-rose-50",
        border: "border-rose-100",
        pieColor: "#f43f5e",
        icon: <ShieldAlert className="w-6 h-6 text-rose-500" />
      };
    }
  };

  const status = getStatusInfo(score);

  const sourceData = [
    { name: 'Bottled Water', value: 45 },
    { name: 'Takeout Containers', value: 25 },
    { name: 'Stored Goods', value: 20 },
    { name: 'Ambient Air', value: 10 },
  ];

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-8 animate-fadeIn">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Good morning, Alex</h1>
          <p className="text-slate-500">Your real-time health and plastic exposure overview.</p>
        </div>
        <div className="flex gap-3">
          <div className="bg-emerald-50 text-emerald-700 px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            12 Day Streak
          </div>
          <div className="bg-rose-50 text-rose-700 px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 border border-rose-100">
            <Baby className="w-4 h-4" />
            Infant Mode Active
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Score Card */}
        <div className={`lg:col-span-2 bg-white p-8 rounded-[2rem] shadow-sm border ${status.border} flex flex-col md:flex-row items-center gap-10 transition-all duration-500`}>
          <div className="relative w-48 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[{ value: score }, { value: 100 - score }]}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  startAngle={90}
                  endAngle={450}
                >
                  <Cell fill={status.pieColor} />
                  <Cell fill="#f1f5f9" />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-5xl font-black ${status.color}`}>{score}</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{status.label}</span>
            </div>
          </div>
          
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-3">
              {status.icon}
              <h2 className="text-2xl font-bold">Daily Intake Score</h2>
            </div>
            <div className={`p-4 rounded-2xl ${status.bg} border ${status.border}`}>
              <p className={`text-lg font-bold ${status.color} leading-tight`}>
                {status.message}
              </p>
            </div>
            <p className="text-slate-500 text-sm">
              Your goal is to stay below <span className="font-bold">30 pts</span> for optimal cellular health and endocrine protection.
            </p>
          </div>
        </div>

        {/* Alerts Card */}
        <div className="bg-slate-900 text-white p-8 rounded-[2rem] space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/10 rounded-full -mr-16 -mt-16 blur-2xl" />
          <div className="flex items-center gap-2 text-teal-400">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="font-bold text-sm uppercase tracking-widest">Urgent Alerts</h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-start gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="w-8 h-8 bg-rose-500/20 rounded-full flex items-center justify-center text-rose-400 shrink-0">
                <Flame className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-sm">Heat Warning</p>
                <p className="text-white/60 text-xs">Recently scanned container (PET) is not microwave safe.</p>
              </div>
            </div>
            <div className="flex items-start gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-blue-400 shrink-0">
                <Baby className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-sm">Pregnancy Tip</p>
                <p className="text-white/60 text-xs">Switch to glass bottles for prenatal supplements.</p>
              </div>
            </div>
          </div>
          <button className="w-full bg-white text-slate-900 font-bold py-3 rounded-xl transition-all hover:bg-teal-50 text-sm">
            View All Insights
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Source Breakdown */}
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100 h-80 flex flex-col">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-500" />
            Primary Sources
          </h3>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sourceData}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {sourceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {sourceData.map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                {item.name}
              </div>
            ))}
          </div>
        </div>

        {/* Actionable Tips */}
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100 space-y-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            Today's Nudges
          </h3>
          <div className="space-y-3 overflow-y-auto max-h-56 pr-2">
            {[
              "Rinse fresh produce in cold water to remove surface particles.",
              "Avoid black plastic kitchen utensils (high BPA risk).",
              "Replace your plastic sponge with a natural loofah.",
              "Choose loose leaf tea over plastic tea bags."
            ].map((tip, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl group cursor-pointer hover:bg-teal-50 transition-colors border border-transparent hover:border-teal-100">
                <p className="text-xs font-semibold text-slate-700 group-hover:text-teal-900 leading-relaxed">{tip}</p>
                <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-teal-400 shrink-0" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
