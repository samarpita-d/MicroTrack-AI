
import React from 'react';
import { ShieldCheck, Activity, Baby, ScanLine, Brain, Database, Leaf, ShieldCheck as ShieldTick, HeartPulse } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="px-6 py-20 md:py-32 max-w-7xl mx-auto text-center">
        <div className="inline-flex items-center px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-sm font-medium mb-6">
          <ShieldCheck className="w-4 h-4 mr-2" />
          Privacy-First Plastic Tracking
        </div>
        <h2 className="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 leading-tight">
          Your personal guide to safer consumption and a <span className="text-teal-600">plastic-aware</span> lifestyle.
        </h2>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-10">
          Track daily intake, analyze packaging risk, and protect your family from microplastics with our AI-driven health platform.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button 
            onClick={onStart}
            className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-4 px-10 rounded-xl shadow-lg transition-all"
          >
            Start Tracking
          </button>
          <button className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold py-4 px-10 rounded-xl transition-all">
            Watch Demo
          </button>
        </div>
      </section>

      {/* Features */}
      <section className="bg-slate-50 py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">Science-backed safety for your family</h3>
            <p className="text-lg text-slate-400">We use latest research and AI to protect what matters most</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<ScanLine className="w-10 h-10 text-teal-500" />}
              title="AI Scanner"
              description="Scan any food packaging or container to instantly identify material type and microplastic leaching risks."
            />
            <FeatureCard 
              icon={<Activity className="w-10 h-10 text-blue-500" />}
              title="Exposure Analytics"
              description="Track your daily plastic intake score and visualize trends over time with detailed health impact reports."
            />
            <FeatureCard 
              icon={<Brain className="w-10 h-10 text-emerald-500" />}
              title="Health Prediction"
              description="AI-driven predictions help you understand the long-term impact of your current habits and lifestyle."
            />
            <FeatureCard 
              icon={<Baby className="w-10 h-10 text-rose-500" />}
              title="Pregnancy & Babies"
              description="Specialized monitoring to protect newborns and expectant mothers from harmful prenatal exposure."
            />
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <h3 className="text-3xl font-bold text-center mb-16 text-slate-900">How MicroTrack AI Protects You</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <Step 
            title="Scan" 
            text="Photograph any food or beverage packaging." 
            icon={<ScanLine className="w-8 h-8" />}
          />
          <Step 
            title="Analyze" 
            text="Our AI identifies materials and chemical release risks." 
            icon={<Brain className="w-8 h-8" />}
          />
          <Step 
            title="Log" 
            text="Add items to your daily intake log automatically." 
            icon={<Database className="w-8 h-8" />}
          />
          <Step 
            title="Reduce" 
            text="Get safer alternatives and healthy habit nudges." 
            icon={<Leaf className="w-8 h-8" />}
          />
        </div>
      </section>

      {/* Privacy Box */}
      <section className="px-6 pb-24 max-w-7xl mx-auto">
        <div className="bg-emerald-900 rounded-[3rem] p-12 md:p-16 text-center text-white shadow-2xl overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
            <div className="absolute -top-24 -left-24 w-96 h-96 bg-emerald-400 rounded-full blur-3xl" />
            <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-teal-400 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 flex flex-col items-center">
            <div className="mb-8 w-20 h-20 rounded-full bg-emerald-800/50 flex items-center justify-center border border-emerald-700">
              <ShieldTick className="w-10 h-10 text-emerald-400" />
            </div>
            <h3 className="text-3xl md:text-4xl font-bold mb-6">Privacy-first data handling</h3>
            <p className="text-emerald-100/80 text-lg max-w-3xl leading-relaxed">
              Your health data is personal. We never sell your data, we use bank-level encryption, 
              and our guidance is 100% brand-neutral.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-slate-100">
    <div className="mb-6">{icon}</div>
    <h4 className="text-xl font-bold mb-3 text-slate-900">{title}</h4>
    <p className="text-slate-600 text-sm leading-relaxed">{description}</p>
  </div>
);

const Step = ({ title, text, icon }: { title: string, text: string, icon: React.ReactNode }) => (
  <div className="flex flex-col items-center text-center group">
    <div className="mb-6 w-16 h-16 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center group-hover:bg-teal-600 group-hover:text-white transition-all duration-300">
      {icon}
    </div>
    <h5 className="text-xl font-bold mb-2 text-slate-800">{title}</h5>
    <p className="text-slate-600 leading-relaxed">{text}</p>
  </div>
);

export default LandingPage;
