
import React from 'react';
import { ShoppingBag, Sparkles, Heart, ThermometerSnowflake, Droplets, Info } from 'lucide-react';

const SafetyHub: React.FC = () => {
  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-8 animate-fadeIn">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Safety Hub</h1>
        <p className="text-slate-500">Curated suggestions for a plastic-free lifestyle.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <RecommendationCard 
          icon={<Droplets className="text-blue-500" />}
          title="Safe Hydration"
          tips={[
            "Swap PET bottles for Borosilicate glass",
            "Use charcoal filters for tap water",
            "Avoid plastic-lined cans for soda"
          ]}
          color="bg-blue-50"
        />
        <RecommendationCard 
          icon={<ShoppingBag className="text-teal-500" />}
          title="Safer Groceries"
          tips={[
            "Choose mesh bags for loose produce",
            "Select items in cardboard or paper",
            "Avoid pre-washed salads in tubs"
          ]}
          color="bg-teal-50"
        />
        <RecommendationCard 
          icon={<ThermometerSnowflake className="text-indigo-500" />}
          title="Storage Mastery"
          tips={[
            "Let food cool before storing",
            "Use beeswax wraps instead of cling film",
            "Store oils in dark glass bottles"
          ]}
          color="bg-indigo-50"
        />
      </div>

      <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm flex flex-col md:flex-row gap-8 items-center">
        <div className="w-24 h-24 bg-rose-50 rounded-full flex items-center justify-center text-rose-500 shrink-0">
          <Heart className="w-12 h-12" />
        </div>
        <div className="space-y-4">
          <h3 className="text-2xl font-bold">Smart Handling Advice</h3>
          <p className="text-slate-600 leading-relaxed">
            Plastic toxicity is highly dependent on temperature and time. Always avoid heating any plastic container, even if marked "microwave safe." These labels often only mean the plastic won't melt, not that it won't leach chemicals.
          </p>
          <div className="flex flex-wrap gap-2">
            {['#BPAFree', '#MicroplasticFree', '#SafetyFirst'].map(tag => (
              <span key={tag} className="text-xs font-bold bg-slate-100 text-slate-500 px-3 py-1 rounded-full">{tag}</span>
            ))}
          </div>
        </div>
      </div>

      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-amber-500" />
          <h3 className="text-xl font-bold">Recommended Alternatives</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { name: "Glass Tiffin Box", price: "$24.00", img: "https://picsum.photos/seed/glass/300/300" },
            { name: "Silicone Storage", price: "$18.50", img: "https://picsum.photos/seed/silicone/300/300" },
            { name: "Bamboo Utensils", price: "$12.00", img: "https://picsum.photos/seed/bamboo/300/300" },
            { name: "Hemp Washcloth", price: "$8.99", img: "https://picsum.photos/seed/hemp/300/300" }
          ].map((item, i) => (
            <div key={i} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 space-y-3 group cursor-pointer">
              <div className="aspect-square rounded-xl overflow-hidden grayscale group-hover:grayscale-0 transition-all">
                <img src={item.img} alt={item.name} className="w-full h-full object-cover" />
              </div>
              <div>
                <p className="font-bold text-slate-900">{item.name}</p>
                <p className="text-sm text-teal-600 font-medium">{item.price}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const RecommendationCard = ({ icon, title, tips, color }: { icon: React.ReactNode, title: string, tips: string[], color: string }) => (
  <div className={`${color} p-8 rounded-3xl space-y-6`}>
    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
      {icon}
    </div>
    <h4 className="text-xl font-bold">{title}</h4>
    <ul className="space-y-3">
      {tips.map((tip, i) => (
        <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
          <div className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0" />
          {tip}
        </li>
      ))}
    </ul>
  </div>
);

export default SafetyHub;
