
import React from 'react';
import { 
  LayoutDashboard, 
  ScanLine, 
  LineChart, 
  ShieldAlert, 
  BookOpen, 
  Baby, 
  Settings,
  LogOut
} from 'lucide-react';
import { AppState } from '../types';
import Logo from './Logo';

interface SidebarProps {
  currentView: AppState;
  setView: (view: AppState) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: 'DASHBOARD' as AppState, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'SCANNER' as AppState, label: 'AI Scanner', icon: ScanLine },
    { id: 'ANALYTICS' as AppState, label: 'Exposure', icon: LineChart },
    { id: 'SAFETY' as AppState, label: 'Safety Hub', icon: ShieldAlert },
    { id: 'EDUCATION' as AppState, label: 'Learning', icon: BookOpen },
    { id: 'INFANT' as AppState, label: 'Infant Care', icon: Baby },
  ];

  return (
    <nav className="w-full md:w-64 bg-white border-r border-slate-200 flex flex-col h-auto md:h-screen sticky top-0 z-50">
      <div className="p-6 flex items-center gap-3">
        <Logo className="w-8 h-8" animate={false} />
        <span className="text-xl font-bold bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent">MicroTrack AI</span>
      </div>
      
      <div className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                isActive 
                  ? 'bg-teal-50 text-teal-700 shadow-sm shadow-teal-100' 
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-teal-600' : 'text-slate-400'}`} />
              {item.label}
            </button>
          );
        })}
      </div>

      <div className="p-4 border-t border-slate-100 space-y-1">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-500 hover:bg-slate-50 transition-colors">
          <Settings className="w-5 h-5 text-slate-400" />
          Settings
        </button>
        <button 
          onClick={() => window.location.reload()}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-rose-500 hover:bg-rose-50 transition-colors"
        >
          <LogOut className="w-5 h-5 text-rose-400" />
          Sign Out
        </button>
      </div>
    </nav>
  );
};

export default Sidebar;
