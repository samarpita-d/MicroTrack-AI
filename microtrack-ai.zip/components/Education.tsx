
import React from 'react';
import { BookOpen, Play, FileText, Info, Award } from 'lucide-react';

const Education: React.FC = () => {
  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-12 animate-fadeIn">
      <header className="text-center max-w-2xl mx-auto space-y-4">
        <h1 className="text-4xl font-black text-slate-900">Plastic Literacy</h1>
        <p className="text-slate-500 text-lg leading-relaxed">
          Knowledge is your first line of defense. Learn how plastics interact with human biology and how to build lasting safety habits.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-10 rounded-[2.5rem] text-white relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl -mr-32 -mt-32" />
          <div className="relative z-10 space-y-6">
            <span className="bg-teal-500/20 text-teal-400 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest">New Course</span>
            <h3 className="text-3xl font-bold leading-tight">Microplastics & Your Endocrine System</h3>
            <p className="text-slate-400">Discover the hidden link between plastic exposure and hormonal balance in this 15-minute module.</p>
            <button className="flex items-center gap-2 bg-white text-slate-900 font-bold px-6 py-3 rounded-xl hover:bg-teal-50 transition-colors">
              <Play className="w-4 h-4 fill-current" /> Start Learning
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-6">
          <ArticleRow 
            title="BPA vs BPS: What's the real difference?" 
            time="5 min read" 
            tag="Chemistry"
          />
          <ArticleRow 
            title="The 7 Types of Plastic: A Cheat Sheet" 
            time="3 min read" 
            tag="Guide"
          />
          <ArticleRow 
            title="Hidden microplastics in your tea bags" 
            time="8 min read" 
            tag="News"
          />
        </div>
      </section>

      <section className="space-y-8">
        <h3 className="text-2xl font-bold">Infographics & Resources</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            "Plastic Breakdown Cycle",
            "Household Hotspots",
            "Ocean to Table Path",
            "Safe Symbols Key"
          ].map((title, i) => (
            <div key={i} className="bg-white border border-slate-100 p-6 rounded-3xl shadow-sm space-y-4 hover:shadow-md transition-shadow cursor-pointer text-center group">
              <div className="aspect-[3/4] bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 group-hover:bg-teal-50 group-hover:text-teal-500 transition-all">
                <FileText className="w-12 h-12" />
              </div>
              <p className="font-bold text-sm text-slate-700">{title}</p>
            </div>
          ))}
        </div>
      </section>

      <div className="bg-amber-50 rounded-[2.5rem] p-10 flex flex-col md:flex-row gap-10 items-center">
        <div className="w-16 h-16 bg-amber-200 rounded-2xl flex items-center justify-center text-amber-700 shrink-0 shadow-sm">
          <Award className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h4 className="text-xl font-bold text-amber-900">Education Progress</h4>
          <p className="text-amber-700/80">You've completed 4/12 fundamental modules. Finish 2 more to unlock the 'Plastic Literate' badge.</p>
          <div className="w-full h-1.5 bg-amber-200 rounded-full mt-4">
            <div className="h-full bg-amber-500 w-1/3 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};

const ArticleRow = ({ title, time, tag }: { title: string, time: string, tag: string }) => (
  <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center justify-between group cursor-pointer hover:border-teal-100">
    <div className="space-y-1">
      <span className="text-[10px] font-black uppercase tracking-widest text-teal-600">{tag}</span>
      <h4 className="font-bold text-slate-900 group-hover:text-teal-700 transition-colors">{title}</h4>
      <p className="text-xs text-slate-400">{time}</p>
    </div>
    <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 group-hover:bg-teal-50 group-hover:text-teal-500 transition-all">
      <ChevronRight />
    </div>
  </div>
);

const ChevronRight = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
);

export default Education;
