
import React from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend
} from 'recharts';
import { TrendingDown, Calendar, Filter, Download } from 'lucide-react';

const historyData = [
  { day: 'Mon', score: 85, predicted: 80 },
  { day: 'Tue', score: 72, predicted: 78 },
  { day: 'Wed', score: 90, predicted: 76 },
  { day: 'Thu', score: 65, predicted: 74 },
  { day: 'Fri', score: 58, predicted: 72 },
  { day: 'Sat', score: 45, predicted: 70 },
  { day: 'Sun', score: 48, predicted: 68 },
];

const sourceData = [
  { category: 'Beverages', current: 40, previous: 55 },
  { category: 'Stored Food', current: 25, previous: 30 },
  { category: 'Air/Dust', current: 15, previous: 15 },
  { category: 'Kitchenware', current: 20, previous: 25 },
];

const Analytics: React.FC = () => {
  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-8 animate-fadeIn">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Exposure Analytics</h1>
          <p className="text-slate-500">Track your progress and AI-based exposure predictions.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-slate-50">
            <Calendar className="w-4 h-4" /> Weekly
          </button>
          <button className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-slate-50">
            <Download className="w-4 h-4" /> Export
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-lg">Exposure Trends</h3>
            <div className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest">
              <span className="flex items-center gap-1.5 text-teal-600">
                <div className="w-2 h-2 rounded-full bg-teal-600" /> Actual
              </span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <div className="w-2 h-2 rounded-full bg-slate-300" /> AI Predicted
              </span>
            </div>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={historyData}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0d9488" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#0d9488" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} 
                />
                <Area type="monotone" dataKey="score" stroke="#0d9488" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
                <Area type="monotone" dataKey="predicted" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" fill="transparent" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-teal-600 p-8 rounded-3xl text-white space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
              <TrendingDown className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold">Reduction Target</h3>
            <p className="text-teal-50/80 leading-relaxed">
              Based on your habits, we predict you can reach <span className="font-bold text-white">Score 30</span> (Optimal) within 3 weeks by switching your meal prep containers.
            </p>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm font-bold">
              <span>Progress</span>
              <span>65%</span>
            </div>
            <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-white w-[65%] rounded-full" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <h3 className="text-lg font-bold mb-8">Category Comparison</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={sourceData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="category" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
              <YAxis axisLine={false} tickLine={false} />
              <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '16px' }} />
              <Legend verticalAlign="top" align="right" iconType="circle" wrapperStyle={{ paddingBottom: '20px' }} />
              <Bar dataKey="current" name="This Week" fill="#0ea5e9" radius={[10, 10, 0, 0]} />
              <Bar dataKey="previous" name="Last Week" fill="#cbd5e1" radius={[10, 10, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
