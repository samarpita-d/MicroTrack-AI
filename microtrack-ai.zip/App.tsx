
import React, { useState, useEffect } from 'react';
import WelcomeScreen from './components/WelcomeScreen';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import Scanner from './components/Scanner';
import Analytics from './components/Analytics';
import SafetyHub from './components/SafetyHub';
import Education from './components/Education';
import InfantTracker from './components/InfantTracker';
import Sidebar from './components/Sidebar';
import { AppState } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<AppState>('WELCOME');

  const renderView = () => {
    switch (view) {
      case 'WELCOME':
        return <WelcomeScreen onContinue={() => setView('LANDING')} />;
      case 'LANDING':
        return <LandingPage onStart={() => setView('DASHBOARD')} />;
      case 'DASHBOARD':
        return <Dashboard />;
      case 'SCANNER':
        return <Scanner />;
      case 'ANALYTICS':
        return <Analytics />;
      case 'SAFETY':
        return <SafetyHub />;
      case 'EDUCATION':
        return <Education />;
      case 'INFANT':
        return <InfantTracker />;
      default:
        return <Dashboard />;
    }
  };

  const showNav = view !== 'WELCOME' && view !== 'LANDING';

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {showNav && <Sidebar currentView={view} setView={setView} />}
      <main className={`flex-1 ${showNav ? 'md:ml-0' : ''}`}>
        {renderView()}
      </main>
    </div>
  );
};

export default App;
