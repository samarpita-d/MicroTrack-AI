
export type AppState = 'WELCOME' | 'LANDING' | 'DASHBOARD' | 'SCANNER' | 'ANALYTICS' | 'SAFETY' | 'EDUCATION' | 'INFANT';

export interface ScanResult {
  productName: string;
  materialType: string;
  riskLevel: 'Low' | 'Medium' | 'High';
  heatRisk: string;
  recommendations: string[];
  timestamp: string;
}

export interface ExposureData {
  date: string;
  score: number;
  sources: { name: string; value: number }[];
}

export interface UserProfile {
  name: string;
  dailyGoal: number;
  notifications: boolean;
  infantMode: boolean;
}
